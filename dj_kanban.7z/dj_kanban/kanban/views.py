from .models import Kanban, Task
from django.conf import settings
from django.shortcuts import render
from django.views import generic
from django.urls import reverse_lazy
from django.contrib.auth import views


class LoginView(views.LoginView):
    fields = "__all__"
    template_name = "kanban/login.html"


class LogoutView(views.LogoutView):
    template_name = "kanban/logout.html"


class KanbanCreateView(generic.CreateView):
    model = Kanban
    template_name = "kanban/kanban_create.html"
    fields = '__all__'
    success_url = reverse_lazy("index")


class KanbanListView(generic.ListView):
    model = Kanban
    template_name = "kanban/index.html"
    context_object_name = "kanbans"  # default - object_list

    def get_context_data(self, *, object_list=None, **kwargs):
        context = super().get_context_data(**kwargs)
        context['MEDIA_URL'] = settings.MEDIA_URL
        return context


class KanbanDetailView(generic.DetailView):
    model = Kanban
    template_name = "kanban/kanban_detail.html"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["tasks_planned"] = None
        context["tasks_active"] = None
        context["tasks_completed"] = None
        context["tasks_overdue"] = None
        return context


class KanbanDeleteView(generic.DeleteView):
    model = Kanban
    template_name = "kanban/kanban_delete.html"
    success_url = reverse_lazy("kanban:index")

class TaskCreateView(generic.CreateView):
    model = Task
    template_name = "kanban/task_create.html"
    success_url = reverse_lazy("kanban:index")
    fields = "__all__"

class TaskDeleteView(generic.DeleteView):
    model = Task
    template_name = "kanban/task_delete.html"
    def get_success_url(self):
        return reverse_lazy(
            "kanban:kanban_detail",
            kwargs = {"pk": self.object.kanban.pk}
        )