from .models import Kanban, Task
from django.conf import settings
from django.shortcuts import render, get_object_or_404
from django.views import generic
from django.urls import reverse_lazy
from django.contrib.auth import views
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin


class LoginView(views.LoginView):
    fields = "__all__"
    template_name = "kanban/login.html"

class LogoutView(views.LogoutView):
    next_page = reverse_lazy("kanban:index")

class KanbanCreateView(LoginRequiredMixin, generic.CreateView):
    model = Kanban
    template_name = "kanban/kanban_create.html"
    fields = '__all__'
    success_url = reverse_lazy("kanban:index")
    login_url = reverse_lazy("kanban:login")

class KanbanListView(generic.ListView):
    model = Kanban
    template_name = "kanban/index.html"
    context_object_name = "kanbans"

class KanbanDetailView(generic.DetailView):
    model = Kanban
    template_name = "kanban/kanban_detail.html"

    def get_context_data(self, **kwargs):
        kanban = self.get_object()
        context = super().get_context_data(**kwargs)
        context["tasks_planned"] = Task.objects.filter(kanban=kanban, status="Planned")
        context["tasks_active"] = Task.objects.filter(kanban=kanban, status="Active")
        context["tasks_completed"] = Task.objects.filter(kanban=kanban, status="Completed")
        context["tasks_overdue"] = Task.objects.filter(kanban=kanban, status="Overdue")
        return context

class KanbanDeleteView(LoginRequiredMixin, generic.DeleteView):
    model = Kanban
    template_name = "kanban/kanban_delete.html"
    success_url = reverse_lazy("kanban:index")
    login_url = reverse_lazy("kanban:login")

    def test_func(self) -> bool | None:
        task = self.get_object()
        return task.kanban.owner == self.request.user

    def handle_no_permission(self):
        return render(self.request, "kanban/403.html")

class TaskCreateView(LoginRequiredMixin, UserPassesTestMixin, generic.CreateView):
    model = Task
    template_name = "kanban/task_create.html"
    success_url = reverse_lazy("kanban:index")
    fields = ['name', 'description']
    login_url = reverse_lazy("kanban:login")

    def handle_no_permission(self):
        return render(self.request, "kanban/403.html")

    def test_func(self) -> bool | None:
        task = self.get_object()
        return task.kanban.owner == self.request.user

    def get_success_url(self):
        return reverse_lazy(
            "kanban:kanban_detail",
            kwargs = {'pk': self.object.kanban.pk}
        )

    def form_valid(self, form):
        form.instance.kanban = Kanban.objects.get(id=self.kwargs['pk'])
        return super().form_valid(form)

class TaskDeleteView(LoginRequiredMixin, generic.DeleteView):
    model = Task
    template_name = "kanban/task_delete.html"

    def handle_no_permission(self):
        return render(self.request, "kanban/403.html")

    def test_func(self) -> bool | None:
        task = self.get_object()
        return task.kanban.owner == self.request.user

    def get_success_url(self):
        return reverse_lazy(
            "kanban:kanban_detail",
            kwargs = {"pk": self.object.kanban.pk}
        )
    login_url = reverse_lazy("kanban:login")
    
def task_activate(request):
    """
    task = self.get_object()
    task.status = "Active"
    """
    return render(request, "kanban/index.html")
