from django.urls import path
from .views import (
    KanbanCreateView,
    KanbanListView,
    KanbanDeleteView,
    KanbanDetailView,
    TaskCreateView,
    TaskDeleteView,
    TaskActivateView,
    TaskCompleteView,
    LoginView,
    LogoutView,
)

app_name = "kanban"

urlpatterns = [
    path("", KanbanListView.as_view(), name="index"),
    path("kanban_create", KanbanCreateView.as_view(), name="kanban_create"),
    path("kanban_delete/<int:pk>", KanbanDeleteView.as_view(), name="kanban_delete"),
    path("kanban_detail/<int:pk>", KanbanDetailView.as_view(), name="kanban_detail"),
    path("task_create/<int:pk>", TaskCreateView.as_view(), name="task_create"),
    path("task_delete/<int:pk>", TaskDeleteView.as_view(), name="task_delete"),
    path("task_activate/<int:pk>", TaskActivateView.as_view(), name="task_activate"),
    path("task_complete/<int:pk>", TaskCompleteView.as_view(), name="task_complete"),
    path("login", LoginView.as_view(), name="login"),
    path("logout", LogoutView.as_view(), name="logout"),
]